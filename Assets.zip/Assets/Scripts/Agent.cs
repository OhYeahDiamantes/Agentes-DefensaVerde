using UnityEngine;

public abstract class Agent : MonoBehaviour
{
    public float health;
    public float maxHealth;
    public bool isAlive => health > 0;

    public virtual void TakeDamage(float damage)
    {
        health -= damage;
        if (health <= 0)
        {
            health = 0;
            Die();
        }
    }

    protected abstract void Die();

    // M�todo virtual para la simulaci�n de cada paso.
    public abstract void Simulate();
}
