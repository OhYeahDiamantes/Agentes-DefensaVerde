using UnityEngine;
using UnityEngine.SceneManagement; // Reiniciar o cargar una escena de fin de juego.

public class House : MonoBehaviour
{
    public GameManager gameManager; // Referencia al GameManager para notificar la derrota.

    [Header("Sonidos de la Casa")]
    [SerializeField] private AudioClip zombieReachedHouseSound; // Sonido cuando un zombi llega a la casa.
    private AudioSource audioSource;                          // Referencia al componente AudioSource.

    void Awake()
    {
        // Obtener o a�adir el AudioSource al GameObject de la Casa.
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
        audioSource.playOnAwake = false;
        audioSource.loop = false;
    }

    // Si un zombi entra a la casa.
    public void ZombieReachedHouse()
    {
        Debug.Log("A Zombie reached the house! Game Over!");

        // Reproducir sonido cuando un zombi llega a la casa.
        if (zombieReachedHouseSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(zombieReachedHouseSound);
        }

        if (gameManager != null)
        {
            gameManager.GameOver(false); // Notificar al GameManager la derrota.
        }
        else
        {
            Time.timeScale = 0; // Pausar todo
        }
    }
}
