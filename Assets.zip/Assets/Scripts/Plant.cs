using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class Plant : Agent
{
    public float attackDamage;
    public float attackRange; // Distancia horizontal de ataque.
    public float attackCooldown;
    private float _currentCooldown;
    public GameObject projectilePrefab;

    public float laneTolerance = 0.5f;


    void Start()
    {
        _currentCooldown = 0;
    }

    public override void Simulate()
    {
        if (!isAlive) return;

        _currentCooldown -= Time.deltaTime;

        // Llamar a la funci�n para encontrar el zombi objetivo en su carril correspondiente.
        Zombie targetZombie = FindTargetZombieInLane();
        if (targetZombie != null && _currentCooldown <= 0)
        {
            Attack(targetZombie);
            _currentCooldown = attackCooldown;
        }
    }

    protected override void Die()
    {
        Debug.Log($"Plant {name} has died.");
        Destroy(gameObject); // Eliminar la planta del juego.
    }
    private Zombie FindTargetZombieInLane()
    {

        List<Zombie> allZombies = new List<Zombie>(FindObjectsByType<Zombie>(FindObjectsSortMode.None));

        Zombie closestZombie = null;

        foreach (Zombie zombie in allZombies)   
        {
            if (zombie == null || !zombie.isAlive) continue; // Ignorar zombis muertos o nulos.

            bool inSameLane = Mathf.Abs(transform.position.y - zombie.transform.position.y) < laneTolerance;

            //Verificar si el zombi est� dentro del rango horizontal.
            bool inHorizontalRange = (zombie.transform.position.x > transform.position.x) &&
                                     (zombie.transform.position.x - transform.position.x <= attackRange);

            if (inSameLane && inHorizontalRange)
            {
                if (closestZombie == null || zombie.transform.position.x < closestZombie.transform.position.x)
                {
                    closestZombie = zombie;
                }
            }
        }
        return closestZombie;
    }

    private void Attack(Zombie target)
    {
        Debug.Log($"Plant {name} is attacking {target.name}");
        GameObject projectile = Instantiate(projectilePrefab, transform.position, Quaternion.identity);
        Projectile projScript = projectile.GetComponent<Projectile>();
        if (projScript != null)
        {
            // Pasar el da�o y la posici�n del objetivo de la planta al proyectil
            projScript.Initialize(attackDamage, target.transform.position, transform.position.y); 
        }
    }

    void OnDrawGizmosSelected()
    {
        // Rango horizontal de ataque.
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + Vector3.right * attackRange);

        Gizmos.color = Color.blue;
        // Dibujar un �rea que representa la tolerancia en Y.
        Vector3 leftBound = new Vector3(-100f, transform.position.y, transform.position.z);
        Vector3 rightBound = new Vector3(100f, transform.position.y, transform.position.z);
        Gizmos.DrawLine(leftBound + Vector3.up * laneTolerance / 2, rightBound + Vector3.up * laneTolerance / 2);
        Gizmos.DrawLine(leftBound + Vector3.down * laneTolerance / 2, rightBound + Vector3.down * laneTolerance / 2);
    }
}