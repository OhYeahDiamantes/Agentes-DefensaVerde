using UnityEngine;
using System.Collections.Generic;

public class Simulate : MonoBehaviour
{
    // Listas para almacenar todas las entidades activas.
    public List<Plant> activePlants = new List<Plant>();
    public List<Zombie> activeZombies = new List<Zombie>();

    // Referencia a la casa.
    public House house;

    //Referencia al GameManager.
    public GameManager gameManager;

    void Update()
    {
        // Iterar sobre las plantas y llamar a su m�todo Simulate.
        for (int i = activePlants.Count - 1; i >= 0; i--)
        {
            if (activePlants[i] == null || !activePlants[i].isAlive) // Eliminar plantas muertas.
            {
                activePlants.RemoveAt(i);
                continue;
            }
            activePlants[i].Simulate();
        }

        // Iterar sobre los zombis y llamar a su m�todo Simulate.
        for (int i = activeZombies.Count - 1; i >= 0; i--)
        {
            if (activeZombies[i] == null || !activeZombies[i].isAlive) // Eliminar zombis muertos.
            {
                activeZombies.RemoveAt(i);
                continue;
            }
            activeZombies[i].Simulate();
        }
    }

    public void AddPlant(Plant newPlant)
    {
        activePlants.Add(newPlant);
    }

    public void AddZombie(Zombie newZombie)
    {
        activeZombies.Add(newZombie);
    }
}

