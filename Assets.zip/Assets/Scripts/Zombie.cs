using UnityEngine;

public class Zombie : Agent
{
    public float moveSpeed = 1f;
    public float attackDamage = 5f;
    public float attackCooldown = 1.5f;
    private float _currentAttackCooldown;

    public bool isStronger;
    public bool isFaster;

    private Plant _targetPlant;

    [Header("Sonidos de Zombie")]
    [SerializeField] private AudioClip spawnSound;   // Sonido al aparecer.
    [SerializeField] private AudioClip attackSound;  // Sonido al atacar.
    private AudioSource audioSource;                 // Referencia al componente AudioSource.

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
        audioSource.playOnAwake = false;
        audioSource.loop = false;
    }

    void Start()
    {
        _currentAttackCooldown = 0;

        // Reproducir el sonido de aparici�n.
        if (spawnSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(spawnSound);
        }

        ApplyRandomModifiers();
    }

    private void ApplyRandomModifiers()
    {
        if (Random.value < 0.3f)
        {
            isStronger = true;

            // Modifica la salud y la maxHealth si es m�s fuerte.
            health = maxHealth * 1.5f;
            maxHealth = health;
            attackDamage *= 1.2f;
        }
        if (Random.value < 0.3f)
        {
            isFaster = true;
            moveSpeed *= 1.5f;
        }
    }

    public override void Simulate()
    {
        if (!isAlive)
        {
            return;
        }

        _currentAttackCooldown -= Time.deltaTime;

        _targetPlant = FindTargetPlant();

        if (_targetPlant != null && _targetPlant.isAlive)
        {
            if (_currentAttackCooldown <= 0)
            {
                AttackPlant(_targetPlant);
                _currentAttackCooldown = attackCooldown;
            }
        }
        else
        {
            MoveTowardsHouse();
        }
    }

    protected override void Die()
    {
        Destroy(gameObject);
    }

    private Plant FindTargetPlant()
    {
        LayerMask plantLayer = LayerMask.GetMask("Plant");
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.left, 0.5f, plantLayer);
        if (hit.collider != null)
        {
            return hit.collider.GetComponent<Plant>();
        }
        return null;
    }

    private void MoveTowardsHouse()
    {
        transform.Translate(Vector2.left * moveSpeed * Time.deltaTime);
    }

    private void AttackPlant(Plant plant)
    {
        plant.TakeDamage(attackDamage);

        //Reproducir el sonido de ataque.
        if (attackSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(attackSound);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("House"))
        {
            House house = other.GetComponent<House>();
            if (house != null)
            {
                house.ZombieReachedHouse();
            }
            Die();
        }
    }
}