using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using TMPro;

public class GameManager : MonoBehaviour
{
    public Simulate simManager;
    public GameObject zombiePrefab;
    public Transform[] zombieSpawnPoints;

    public float timeBetweenWaves = 10f;
    public int zombiesPerWave = 5;
    public float timeBetweenZombieSpawns = 1f;

    [Header("Configuraci�n de Oleadas")]
    public int totalWaves = 5;
    private int _currentWave = 0;

    private bool _gameOver = false;
    public TextMeshProUGUI statusText;

    //Referencia al bot�n de reinicio.
    [Header("UI Elementos")]
    public GameObject restartButtonGO; // Referencia al GameObject del bot�n de reinicio.

    void Start()
    {
        if (simManager == null)
        {
            simManager = Object.FindFirstObjectByType<Simulate>();
            if (simManager == null)
            {
                Debug.LogError("Simulate script not found!");
                enabled = false;
                return;
            }
        }

        Time.timeScale = 1;
        _gameOver = false; // Asegurarse de que el estado de juego no est� terminado al inicio.
        _currentWave = 0;  // Reiniciar el contador de oleadas al inicio.

        //Ocultar el bot�n de reinicio al principio.
        if (restartButtonGO != null)
        {
            restartButtonGO.SetActive(false);
        }

        StartCoroutine(SpawnWaves());
        UpdateStatusText($"Wave {_currentWave}/{totalWaves}!");
    }

    IEnumerator SpawnWaves()
    {
        while (!_gameOver && _currentWave < totalWaves)
        {
            _currentWave++;
            UpdateStatusText($"Wave {_currentWave}/{totalWaves}!");

            for (int i = 0; i < zombiesPerWave; i++)
            {
                SpawnZombie();
                yield return new WaitForSeconds(timeBetweenZombieSpawns);
            }

            if (_currentWave < totalWaves)
            {
                yield return new WaitForSeconds(timeBetweenWaves);
                zombiesPerWave += 2;
            }
        }

        if (!_gameOver)
        {
            yield return new WaitForSeconds(5f); // Peque�o retardo final antes de verificar la victoria.

            if (simManager.activeZombies.Count == 0)
            {
                GameOver(true);
            }
            else
            {
                yield return StartCoroutine(WaitForAllZombiesCleared());
                if (simManager.activeZombies.Count == 0)
                {
                    GameOver(true);
                }
            }
        }
    }

    IEnumerator WaitForAllZombiesCleared()
    {
        while (simManager.activeZombies.Count > 0 && !_gameOver)
        {
            yield return null;
        }
    }

    void SpawnZombie()
    {
        if (zombieSpawnPoints.Length > 0)
        {
            Transform spawnPoint = zombieSpawnPoints[Random.Range(0, zombieSpawnPoints.Length)];
            GameObject newZombieGO = Instantiate(zombiePrefab, spawnPoint.position, Quaternion.identity);
            Zombie newZombie = newZombieGO.GetComponent<Zombie>();
            if (newZombie != null)
            {
                simManager.AddZombie(newZombie);
            }
        }
    }

    public void GameOver(bool won)
    {
        if (_gameOver) return;
        _gameOver = true;
        Time.timeScale = 0;

        if (won)
        {
            UpdateStatusText("VICTORY!");
        }
        else
        {
            UpdateStatusText("DEFEAT!");
        }

        //Mostrar el bot�n de reinicio.
        if (restartButtonGO != null)
        {
            restartButtonGO.SetActive(true);
        }
    }

    private void UpdateStatusText(string message)
    {
        if (statusText != null)
        {
            statusText.text = message;
        }
        Debug.Log(message);
    }

    //Reiniciar la simulaci�n.
    public void RestartSimulation()
    {
        Debug.Log("Reiniciando simulaci�n...");
        Time.timeScale = 1; // Asegurarse de que el tiempo no est� pausado antes de recargar.
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); // Recargar la escena actual.
    }
}