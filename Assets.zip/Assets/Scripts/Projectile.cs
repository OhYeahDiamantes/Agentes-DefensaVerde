using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 10f;
    public float damage = 10f;
    private Vector3 _targetPosition;
    private float _laneY; //Coordenada Y del carril del proyectil.

    //M�todo Initialize con la Y del carril.
    public void Initialize(float dmg, Vector3 targetPos, float laneY)
    {
        damage = dmg;
        _targetPosition = targetPos;
        _laneY = laneY;

        transform.position = new Vector3(transform.position.x, _laneY, transform.position.z);
    }

    void Update()
    {
        if (_laneY == 0 && transform.position.y == 0 && transform.position.x == 0) return;

        Vector3 currentTargetInLane = new Vector3(_targetPosition.x, _laneY, _targetPosition.z);
        transform.position = Vector3.MoveTowards(transform.position, currentTargetInLane, speed * Time.deltaTime);

        // Si llega cerca de la X del objetivo, se destruye.
        if (Mathf.Abs(transform.position.x - currentTargetInLane.x) < 0.2f)
        {
            Destroy(gameObject);
        }

        if (transform.position.x > 20f || transform.position.x < -20f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Detecci�n de colisi�n con zombis.
        Zombie zombie = other.GetComponent<Zombie>();
        
        // Verificar que el zombi est� en el mismo carril antes de aplicar da�o.
        float projectileLaneTolerance = 0.6f;
        if (zombie != null && zombie.isAlive && Mathf.Abs(transform.position.y - zombie.transform.position.y) < projectileLaneTolerance)
        {
            zombie.TakeDamage(damage);
            Destroy(gameObject); // Destruir el proyectil al impactar.
        }
    }
}